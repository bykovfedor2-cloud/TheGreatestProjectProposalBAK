import bpy,bmesh,math,os,json,struct,itertools
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
OUT=os.path.abspath('outputs/backpack_v03'); os.makedirs(OUT+'/stl',exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.context.preferences.filepaths.save_version=0
sc=bpy.context.scene;sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.001
parts={};joints=[];refs=[]

def material(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True
 m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*c,1)
 m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.48
 return m
black=material('PLA graphite',(.055,.085,.11));orange=material('PLA orange',(.8,.18,.035));gray=material('Reference gray',(.32,.39,.43));silver=material('Equipment reference',(.5,.55,.59))

def cube(lo,hi):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(Vector(lo)+Vector(hi))/2)
 o=bpy.context.object;o.dimensions=Vector(hi)-Vector(lo);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return o

def cylinder(p,axis,r,length,vertices=48):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=length,location=p);o=bpy.context.object
 o.rotation_euler=Vector(axis).to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);return o

def boolean(o,c,op='DIFFERENCE'):
 bpy.context.view_layer.objects.active=o
 m=o.modifiers.new(op,'BOOLEAN');m.operation=op;m.solver='EXACT';m.object=c
 bpy.ops.object.modifier_apply(modifier=m.name);bpy.data.objects.remove(c,do_unlink=True);return o

def union(items):
 o=items[0]
 for c in items[1:]:boolean(o,c,'UNION')
 return o

def prism(points,axis,lo,hi):
 # points lie in the two remaining axes, in cyclic polygon order.
 others=[i for i in range(3) if i!=axis];verts=[]
 for value in [lo,hi]:
  for a,b in points:
   p=[0,0,0];p[axis]=value;p[others[0]]=a;p[others[1]]=b;verts.append(p)
 n=len(points);faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 mesh=bpy.data.meshes.new('Prism');mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new('Prism',mesh);sc.collection.objects.link(o)
 bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free();return o

def part(id,o,color=black):
 o.name=id;o.data.materials.clear();o.data.materials.append(color);parts[id]=o;return id

def cut(id,lo,hi):boolean(parts[id],cube(lo,hi))
def hole(id,p,axis,d,length=400):boolean(parts[id],cylinder(p,axis,d/2,length))
def hexnut(id,p,axis,af,depth):boolean(parts[id],cylinder(p,axis,af/math.sqrt(3),depth+.4,6))
def joint(id,ids,p,axis,d,screw,span,skip=()):
 for name in ids:
  if name not in skip:hole(name,p,axis,d)
 joints.append({'id':id,'parts':ids,'center_mm':list(p),'axis':list(axis),'hole_d_mm':d,'hardware':screw,'span_mm':span})
def slot(id,p,axis,width,length,along):
 ai=max(range(3),key=lambda i:abs(axis[i]));li=max(range(3),key=lambda i:abs(along[i]));si=next(i for i in range(3) if i not in [ai,li]);other=[i for i in range(3) if i!=ai]
 r=width/2;offset=(length-width)/2;points=[]
 for sign,angles in [(1,range(-90,91,6)),(-1,range(90,271,6))]:
  for angle in angles:
   q=list(p);q[li]+=sign*offset+r*math.cos(math.radians(angle));q[si]+=r*math.sin(math.radians(angle));points.append((q[other[0]],q[other[1]]))
 boolean(parts[id],prism(points,ai,p[ai]-200,p[ai]+200))

def shell_id(x,z):return f'A{0 if x<0 else 1}{0 if z<180 else 1}_shell'
# Four structural tray modules. All other printed pieces connect to these modules.
for sx in [-1,1]:
 for iz in [0,1]:
  x0,x1=(-140,0) if sx<0 else (0,140);z0=180*iz;z1=z0+180
  solids=[cube((x0,0,z0),(x1,8,z1))]
  wx0,wx1=(-140,-136) if sx<0 else (136,140)
  solids.append(cube((wx0,7.8,z0),(wx1,96,z1)))
  if iz==0:solids.append(cube((x0,7.8,0),(x1,96,4)))
  else:solids.append(cube((x0,7.8,356),(x1,96,360)))
  for x in [x0+7,x1-7]:
   for z in [z0+7,z1-7]:solids.append(cube((x-6,7.8,z-6),(x+6,96,z+6)))
  sid=part(shell_id((x0+x1)/2,(z0+z1)/2),union(solids))
  # Side ventilation strips, away from posts and load entry.
  for z in [z0+40,z0+60,z0+80,z0+100,z0+120]:
   cut(sid,(wx0-1,43,z),(wx1+1,82,z+6))
  lid=part(f'B{0 if sx<0 else 1}{iz}_lid',cube((x0+.25,96,z0+.25),(x1-.25,100,z1-.25)))
  for x in [x0+30,x0+50,x0+70,x0+90,x0+110]:cut(lid,(x-3,95,z0+35),(x+3,101,z0+95))
  for k,(x,z) in enumerate(itertools.product([x0+7,x1-7],[z0+7,z1-7])):
   joint(f'{lid}_screw{k}',[sid,lid],(x,96,z),(0,1,0),3.4,'M3x12 + nut',12)
   hexnut(sid,(x,94.25,z),(0,1,0),5.8,3.5)
# Passage for the structural mast through the upper right module.
cut('A01_shell',(-140,8,260),(-69,31,361))
# Front frame splice plates, common bores through every touching module.
for i,(cx,cz,w,h,ids) in enumerate([(0,60,50,50,['A00_shell','A10_shell']),(0,300,50,50,['A01_shell','A11_shell']),(-100,180,50,60,['A00_shell','A01_shell']),(100,180,50,60,['A10_shell','A11_shell'])]):
 id=part(f'C{i}_frame_splice',cube((cx-w/2,-8,cz-h/2),(cx+w/2,0,cz+h/2)),orange)
 for j,(dx,dz) in enumerate(itertools.product([-15,15],[-18,18])):
  p=(cx+dx,0,cz+dz);target=shell_id(p[0],p[2]);joint(f'{id}_{j}',[id,target],p,(0,1,0),4.5,'M4x25 + washers + nut',16)
# Textile anchors: actual slots cut through shell backplate, no printed buckles.
for x in [-40,40]:
 sid=shell_id(x,345);slot(sid,(x,4,345),(0,1,0),4,54,(1,0,0))
for x in [-65,65]:slot(shell_id(x,25),(x,4,25),(0,1,0),4,30,(1,0,0))
for x in [-118,118]:slot(shell_id(x,55),(x,4,55),(0,1,0),4,54,(0,0,1))
# One-piece lateral root, with a large diagonal web and broad four-bolt attachment.
root=part('D0_shoulder_root',prism([(-140,260),(-70,260),(-70,410),(-265,410),(-265,350),(-140,315)],1,8,30),orange)
# Leave space around the lid pillar instead of intersecting it.
cut(root,(-140,7,346),(-126,31,360))
# A lightening window maintains broad borders; not an FEA claim.
boolean(parts[root],prism([(-150,355),(-235,380),(-150,390)],1,7,31))
for i,(x,z) in enumerate(itertools.product([-125,-85],[280,310])):joint(f'root_mount_{i}',['A01_shell',root],(x,8,z),(0,1,0),5.5,'M5x40 + wide washers + nut',30)
# Forward carrier, with integrated twin triangular gussets.
solids=[cube((-265,-4,340),(-205,8,410)),cube((-265,-145,398),(-205,8,410))]
for x in [-265,-213]:solids.append(prism([(-144,398.2),(7.8,340.2),(7.8,398.2)],0,x,x+8))
carrier=part('D1_forward_carrier',union(solids))
for i,(x,z) in enumerate(itertools.product([-250,-220],[365,395])):joint(f'carrier_root_{i}',[root,carrier],(x,8,z),(0,1,0),5.5,'M5x45 + washers + nut',34)
# Platform unchanged: 120 × 140 × 8 mm. Connection fasteners recessed below motors.
platform=part('D2_platform_120x140',cube((-295,-145,410),(-175,-5,418)))
for i,(x,y) in enumerate(itertools.product([-249,-221],[-125,-25])):
 joint(f'platform_carrier_{i}',[platform,carrier],(x,y,410),(0,0,1),5.5,'M5 countersunk x25 + nut',20,skip=[platform])
 # 90-degree countersink, 11 mm top diameter.
 verts=[];faces=[];n=48
 for zz,rr in [(400,2.75),(415.25,2.75),(418.5,6),(430,6)]:
  verts.extend([(x+rr*math.cos(2*math.pi*k/n),y+rr*math.sin(2*math.pi*k/n),zz) for k in range(n)])
 faces=[tuple(reversed(range(n))),tuple(range(3*n,4*n))]
 for level in range(3):
  for k in range(n):faces.append((level*n+k,level*n+(k+1)%n,(level+1)*n+(k+1)%n,(level+1)*n+k))
 mesh=bpy.data.meshes.new('Countersink tool');mesh.from_pydata(verts,[],faces);mesh.update();tool=bpy.data.objects.new('Countersink tool',mesh);sc.collection.objects.link(tool)
 boolean(parts[platform],tool)
 hexnut(carrier,(x,y,400),(0,0,1),8.4,4)
# Two split body clamps. 57.6 mm open aperture; 1.6 mm split permits closure.
# Bodies vertical; 56 mm height is ONLY an envelope for viewing, not a fit dimension.
for mi,cy in enumerate([-108,-42]):
 ids=[]
 for side in [-1,1]:
  # Construct front half then mirror its y coordinates for rear half.
  def block(a,b):
   lo=[a[0]-235,cy+(a[1] if side>0 else -b[1]),418+a[2]]
   hi=[b[0]-235,cy+(b[1] if side>0 else -a[1]),418+b[2]]
   return cube(lo,hi)
  solids=[block((-46,28.8,0),(46,32,22))]
  for sign in [-1,1]:
   a,b=(28.8,46) if sign>0 else (-46,-28.8)
   solids.append(block((a,.8,0),(b,32,22)))
   a,b=(43,57) if sign>0 else (-57,-43)
   solids.append(block((a,10,0),(b,22,6)))
  id=part(f'E{mi}_{"rear" if side>0 else "front"}_motor_jaw',union(solids),orange);ids.append(id)
  for k,dx in enumerate([-50,50]):
   x=-235+dx;y=cy+side*16
   joint(f'{id}_foot{k}',[id,platform],(x,y,418),(0,0,1),4.5,'M4x25 + wide washers + nut',14,skip=[platform])
   slot(platform,(x,y,414),(0,0,1),4.5,8.5,(0,1,0))
 for k,dx in enumerate([-38,38]):
  x=-235+dx
  joint(f'motor{mi}_clamp{k}',ids,(x,cy,432),(0,1,0),4.5,'M4x75 + washers + nut',64)
  hexnut(ids[1],(x,cy+30,432),(0,1,0),7.4,4)
 # Reference motor envelopes are NOT exported to STL.
 o=cube((-263.5,cy-28.5,419),(-206.5,cy+28.5,475));o.name=f'REF_motor{mi}_57x57x56_UNCONFIRMED_LENGTH';o.data.materials.append(gray);refs.append(o)
 o=cylinder((-235,cy,482),(0,0,1),3.2,14);o.data.materials.append(silver);refs.append(o)
# Internal supply saddles, mounted to the frame, with actual webbing slots.
for i,z in enumerate([65,275]):
 id=part(f'F{i}_power_saddle',cube((15,8,z-12.5),(125,20,z+12.5)),orange)
 for k,x in enumerate([25,115]):joint(f'{id}_mount{k}',[id,shell_id(x,z)],(x,8,z),(0,1,0),4.5,'M4x30 + washers + nut',20)
 for x in [48,92]:slot(id,(x,14,z),(0,1,0),3.5,24,(1,0,0))
# Generic electronics tray; board is retained with ties until its hole pattern is measured.
solids=[cube((-122.5,20,117.5),(-17.5,26,252.5))]
for x,z in itertools.product([-110,-30],[130,240]):solids.append(cube((x-6,8,z-6),(x+6,20.2,z+6)))
id=part('F2_logic_tray',union(solids))
for i,(x,z) in enumerate(itertools.product([-110,-30],[130,240])):joint(f'logic_mount{i}',[id,shell_id(x,z)],(x,8,z),(0,1,0),4.5,'M4x35 + washers + nut',26)
for x in [-100,-70,-40]:
 for z in [155,185,215]:slot(id,(x,23,z),(0,1,0),3.5,16,(1,0,0))
# Two screwed cable guides; tunnel is open along Z.
for i,z in enumerate([85,215]):
 cx=-120 if i==0 else 0
 base=cube((cx-14,8,z-7),(cx+14,12,z+7));arch=cube((cx-6,11.8,z-7),(cx+6,24,z+7))
 id=part(f'F{3+i}_cable_guide',union([base,arch]),orange)
 cut(id,(cx-4,12,z-8),(cx+4,21,z+8))
 for k,x in enumerate([cx-10,cx+10]):joint(f'{id}_mount{k}',[id,shell_id(x,z)],(x,8,z),(0,1,0),3.4,'M3x20 + washers + nut',12)
# PSU envelope for fit visualization only; assumed dimensions from earlier concept.
o=cube((15,21,62.5),(125,76,277.5));o.name='REF_PSU_110x55x215_UNCONFIRMED';o.data.materials.append(silver);refs.append(o)
# Normalize meshes before independent checks.
for id,o in parts.items():
 bpy.context.view_layer.objects.active=o
 bm=bmesh.new();bm.from_mesh(o.data)
 for v in bm.verts:v.co=Vector([round(c,3) for c in v.co])
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.0001);bmesh.ops.dissolve_degenerate(bm,dist=.0002,edges=list(bm.edges));bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method='BEAUTY',ngon_method='EAR_CLIP');bmesh.ops.dissolve_degenerate(bm,dist=.0002,edges=list(bm.edges));bmesh.ops.triangulate(bm,faces=list(bm.faces),ngon_method='EAR_CLIP');bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free();o.data.update()
 o['status']='Prototype geometry; fit and load testing required';o['material']='PLA'
# Geometry, connectivity, bed-envelope and fastener-axis checks.
checks=[];graph={id:set() for id in parts}
for j in joints:
 for a,b in itertools.combinations(j['parts'],2):graph[a].add(b);graph[b].add(a)
seen=set();stack=[next(iter(parts))]
while stack:
 a=stack.pop()
 if a not in seen:seen.add(a);stack.extend(graph[a]-seen)
for id,o in parts.items():
 bm=bmesh.new();bm.from_mesh(o.data)
 nonman=sum(not e.is_manifold for e in bm.edges)
 visited=set();components=0
 for v in bm.verts:
  if v in visited:continue
  components+=1;todo=[v]
  while todo:
   q=todo.pop()
   if q in visited:continue
   visited.add(q);todo.extend(e.other_vert(q) for e in q.link_edges)
 vol=abs(bm.calc_volume(signed=True));bm.free()
 corners=[Vector(v) for v in o.bound_box];dims=[max(v[i] for v in corners)-min(v[i] for v in corners) for i in range(3)]
 fit=False;orient=None
 for heightaxis in range(3):
  if dims[heightaxis]>200.001:continue
  a,b=[dims[i] for i in range(3) if i!=heightaxis]
  for angle in range(91):
   rad=math.radians(angle);w=a*math.cos(rad)+b*math.sin(rad);d=a*math.sin(rad)+b*math.cos(rad)
   if w<=200.001 and d<=200.001:fit=True;orient={'vertical_local_axis':heightaxis,'bed_angle_deg':angle};break
  if fit:break
 checks.append({'part':id,'nonmanifold_edges':nonman,'connected_mesh_components':components,'volume_mm3':round(vol,3),'bbox_mm':[round(v,3) for v in dims],'fits_200_cube':fit,'possible_envelope_orientation':orient,'connected_to_assembly':id in seen})
# Verify bores are actually open through geometry, not only declared in joint metadata.
for j in joints:
 errors=[]
 for id in j['parts']:
  o=parts[id];axis=Vector(j['axis']);p=Vector(j['center_mm']);inv=o.matrix_world.inverted()
  origin=inv@(p-axis*500);direction=(inv.to_3x3()@axis).normalized()
  hit,loc,n,idx=o.ray_cast(origin,direction,distance=1000)
  # Some other feature along the infinite axis may be hit; restrict to mating-span region.
  if hit and abs((o.matrix_world@loc-p).dot(axis))<j['span_mm']+5:errors.append(id)
 j['axis_open_check_errors']=errors
# Positive volume intersections between printed parts (touching faces are allowed).
collisions=[]
world_bounds={id:[o.matrix_world@Vector(v) for v in o.bound_box] for id,o in parts.items()}
for a,b in itertools.combinations(parts,2):
 ca,cb=world_bounds[a],world_bounds[b]
 overlap=[min(max(v[i] for v in ca),max(v[i] for v in cb))-max(min(v[i] for v in ca),min(v[i] for v in cb)) for i in range(3)]
 if min(overlap)<.01:continue
 oa=parts[a];temp=oa.copy();temp.data=oa.data.copy();sc.collection.objects.link(temp)
 bpy.context.view_layer.objects.active=temp
 m=temp.modifiers.new('Interference check','BOOLEAN');m.operation='INTERSECT';m.solver='EXACT';m.object=parts[b]
 bpy.ops.object.modifier_apply(modifier=m.name)
 bm=bmesh.new();bm.from_mesh(temp.data);volume=abs(bm.calc_volume(signed=True));bm.free();bpy.data.objects.remove(temp,do_unlink=True)
 if volume>.1:collisions.append({'a':a,'b':b,'intersection_mm3':round(volume,3)})
report={'units':'mm','status':'PROTOTYPE — no structural load certification','parts':checks,'joints':joints,'unconnected_parts':sorted(set(parts)-seen),'printed_part_interferences':collisions,'assumptions':{'motors':'NEMA23 confirmed; assumed 57x57 mm body; length unknown','clamp_open_aperture_mm':57.6,'clamp_split_mm':1.6,'printer_envelope_assumed_mm':[200,200,200],'total_equipment_mass_kg':1.5,'motor_pair_rearranged':'Two motors placed fore-aft on 120x140 platform. Existing drive geometry must be checked; not reproduced.'}}
with open(OUT+'/verification.json','w') as f:json.dump(report,f,ensure_ascii=False,indent=2)
print('VALIDATION',json.dumps({'parts':len(parts),'joints':len(joints),'mesh_errors':[r for r in checks if r['nonmanifold_edges'] or r['connected_mesh_components']!=1],'oversize':[r['part'] for r in checks if not r['fits_200_cube']],'unconnected':report['unconnected_parts'],'interferences':collisions,'bore_errors':[j['id'] for j in joints if j['axis_open_check_errors']]}),flush=True)
# STL writer: binary, millimetres, one part per file; preserves assembled axes but moves to bed origin.
def write_stl(path,objects,normalize=False,rotation=None):
 triangles=[]
 for o in objects:
  o.data.calc_loop_triangles()
  for t in o.data.loop_triangles:triangles.append([o.matrix_world@o.data.vertices[i].co for i in t.vertices])
 if rotation is not None:triangles=[[rotation@v for v in t] for t in triangles]
 if normalize:
  lo=Vector([min(v[i] for t in triangles for v in t) for i in range(3)])
  triangles=[[v-lo for v in t] for t in triangles]
 with open(path,'wb') as f:
  f.write(b'Backpack v03 prototype; STL dimensions in millimeters'.ljust(80,b' '));f.write(struct.pack('<I',len(triangles)))
  for t in triangles:
   n=(t[1]-t[0]).cross(t[2]-t[0]).normalized();f.write(struct.pack('<12fH',*n,*t[0],*t[1],*t[2],0))
for id,o in parts.items():
 rotation=Matrix.Identity(3)
 if id.startswith(('A','B','C','D0','F0','F1','F3','F4')):rotation=Matrix.Rotation(math.pi/2,3,'X')
 elif id.startswith('F2'):rotation=Matrix.Rotation(-math.pi/2,3,'X')
 elif id.startswith('D1'):rotation=Matrix.Rotation(-math.pi/2,3,'Y')
 write_stl(OUT+'/stl/'+id+'.stl',[o],True,rotation)
write_stl(OUT+'/assembly_reference_mm.stl',list(parts.values()))
# Display-only normals/soft edges do not alter exported files.
for o in parts.values():
 m=o.modifiers.new('Preview edge softness only','BEVEL');m.width=.35;m.segments=2
 o.modifiers.new('Preview normals','WEIGHTED_NORMAL')
# Simplified fit mannequin, never exported.
def ellipsoid(n,loc,scale):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=40,ring_count=24,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(gray)
 for p in o.data.polygons:p.use_smooth=True
 refs.append(o)
ellipsoid('REF_torso',(0,-110,165),(178,102,225));ellipsoid('REF_head',(0,-114,570),(85,94,120));ellipsoid('REF_neck',(0,-105,425),(50,52,65))
for x in [-190,190]:ellipsoid('REF_upper_arm',(x,-105,205),(55,65,175))
# Show cloth harness as curves, purchased hardware; not printable.
for x in [-90,90]:
 curve=bpy.data.curves.new('Harness reference','CURVE');curve.dimensions='3D';curve.bevel_depth=12;curve.bevel_resolution=3
 sp=curve.splines.new('POLY');pts=[(x,0,345),(x,-80,390),(x,-185,355),(x,-205,190),(x,-160,20),(x,0,25)];sp.points.add(len(pts)-1)
 for p,co in zip(sp.points,pts):p.co=(*co,1)
 o=bpy.data.objects.new('REF_textile_harness',curve);sc.collection.objects.link(o);o.data.materials.append(black);refs.append(o)
# Reference labels saved inside project.
text=bpy.data.texts.new('READ_ME');text.write('STL prototype v03. Units mm. Each stl/ file is one printed part. assembly_reference_mm.stl is for viewing only.\nNEMA23 body width confirmed approximately 57 mm; motor length unmeasured. Two motors arranged fore-aft; drive transmission is NOT designed.\nAll modelled printed parts are connected via recorded bolted joints; see verification.json for actual check results.\nPLA strength, heat, layer bonding, bolt access and real fits require physical checks. Print a motor clamp pair first. No load-rating claim. Purchased nuts, bolts, washers, straps and padding required.\n')
sc['revision']='v03 — connected STL prototype';sc['units']='millimetres';sc['material']='PLA';sc['not_verified']='Structural strength, motor length, original drive geometry, real printer and assembly access'
# Studio, in millimetre coordinates.
world=sc.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.19,.23,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5
floor=cube((-5000,-5000,-80),(5000,5000,-75));floor.data.materials.append(black);refs.append(floor)
def light(loc,power,size):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;o.rotation_euler=(Vector((0,0,300))-o.location).to_track_quat('-Z','Y').to_euler()
light((-1000,1500,2000),90000000,1500);light((1000,0,1500),60000000,1200);light((0,-1200,1800),80000000,1000)
bpy.ops.object.camera_add(location=(-1200,1900,1000));cam=bpy.context.object;cam.rotation_euler=(Vector((-35,0,300))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=950;cam.data.clip_end=20000;sc.camera=cam
sc.render.engine='CYCLES';sc.cycles.samples=32;sc.render.resolution_x=1400;sc.render.resolution_y=1400;sc.render.resolution_percentage=100
sc.view_settings.view_transform='AgX'
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':
   area.spaces.active.clip_end=20000;area.spaces.active.region_3d.view_distance=1000;area.spaces.active.region_3d.view_location=Vector((-30,0,300));area.spaces.active.region_3d.view_rotation=cam.rotation_euler.to_quaternion()
bpy.ops.object.select_all(action='DESELECT');parts[platform].select_set(True);bpy.context.view_layer.objects.active=parts[platform]
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/backpack_v03.blend')
sc.render.filepath=OUT+'/assembly.png';bpy.ops.render.render(write_still=True)
# Detail without motor envelopes exposes clamp halves and platform interfaces.
for o in refs:o.hide_render=True
for id,o in parts.items():o.hide_render=not id.startswith(('D','E'))
cam.location=(-650,-700,850);cam.rotation_euler=(Vector((-200,-55,375))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=350
sc.render.filepath=OUT+'/motor_clamps.png';bpy.ops.render.render(write_still=True)
